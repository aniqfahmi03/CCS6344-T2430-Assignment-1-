<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LoginPage</title>
    <link href="css/login.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <section class="copy">
            <img src="images/inst-profile-header-mmu.jpg" class="background-img">
            <h1>Welcome to MMU Lost And Found</h1>
            <p>A platform to reunite with your lost belonging.</p>
        </section>
        <form action="loginfunc.php" method="post">
            <section class="copy">
                <h2>Log In to Your Account</h2>
                <div class="signup-container">
                    <p>Not a member yet? <a href="signup.php"><strong>Sign Up</strong></a></p>
                </div>
            </section>
            <div class="input-container name">
                <label for="username">Username</label>
                <input type="text" name="username" value="<?php echo isset($_COOKIE['remember_username']) ? $_COOKIE['remember_username'] : ''; ?>" required="required">
            </div>
            <div class="input-container password">
                <label for="password">Password</label>
                <input type="password" name="password" required="required">
            </div>
            <div class="remember">
                <label for="remember-me"><input type="checkbox" name="remember" id="remember" <?php echo isset($_COOKIE['remember_username']) ? 'checked' : ''; ?> />Remember me</label>
            </div>
            <button class="login-btn" type="submit" name="login">Login</button>
            <p><a href="forgot_password.php">Forgot your password?</a></p>
        </form>
    </div>
</body>
</html>
