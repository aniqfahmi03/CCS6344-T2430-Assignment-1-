<?php
session_start();
include('db_connection.php');

$conn = OpenCon();

if (!isset($_SESSION["mySession"])) {
    header('Location:login.php');
    exit();
}

$user_id = $_SESSION["mySession"];

if (isset($_POST['update_profile'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone_number = mysqli_real_escape_string($conn, $_POST['phone_number']);
    $profile_picture = null;

    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['size'] > 0) {
        $profile_picture = addslashes(file_get_contents($_FILES['profile_picture']['tmp_name']));
    }

    if ($profile_picture) {
        $query = "UPDATE account SET name='$name', Email='$email', Phone_Number='$phone_number', ProfilePicture='$profile_picture' WHERE User_ID='$user_id'";
    } else {
        $query = "UPDATE account SET name='$name', Email='$email', Phone_Number='$phone_number' WHERE User_ID='$user_id'";
    }

    if (mysqli_query($conn, $query)) {
        header('Location:user/userprofile.php');
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }
}

if (isset($_POST['update_password'])) {
    $current_password = mysqli_real_escape_string($conn, $_POST['current_password']);
    $new_password = mysqli_real_escape_string($conn, $_POST['new_password']);
    $confirm_password = mysqli_real_escape_string($conn, $_POST['confirm_password']);

    $result = mysqli_query($conn, "SELECT Password FROM account WHERE User_ID='$user_id'");
    $row = mysqli_fetch_array($result);
    $stored_password = $row['Password'];

    if ($current_password == $stored_password && $new_password == $confirm_password) {
        $query = "UPDATE account SET Password='$new_password' WHERE User_ID='$user_id'";

        if (mysqli_query($conn, $query)) {
            header('Location: user/userprofile.php');
        } else {
            echo "Error updating password: " . mysqli_error($conn);
        }
    } else {
        echo "Passwords do not match or current password is incorrect.";
    }
}

mysqli_close($conn);
?>
