<?php
session_start();
require_once '../db_connection.php';

if (isset($_POST['delete_btn']) && isset($_POST['item_id'])) {
    $item_id = $_POST['item_id'];

    // Check if there are any claims associated with the item
    $conn = OpenCon();
    $check_query = "SELECT COUNT(*) AS count FROM item_claims WHERE LostItem_ID = ?";
    $check_stmt = mysqli_prepare($conn, $check_query);
    mysqli_stmt_bind_param($check_stmt, "i", $item_id);
    mysqli_stmt_execute($check_stmt);
    mysqli_stmt_bind_result($check_stmt, $claim_count);
    mysqli_stmt_fetch($check_stmt);
    mysqli_stmt_close($check_stmt);

    if ($claim_count > 0) {
        echo "Cannot delete item because it has associated claims.";
    } else {
        // No associated claims, proceed with deletion
        $delete_query = "DELETE FROM lostitem WHERE LostItem_ID = ?";
        $delete_stmt = mysqli_prepare($conn, $delete_query);
        mysqli_stmt_bind_param($delete_stmt, "i", $item_id);

        if (mysqli_stmt_execute($delete_stmt)) {
            echo "Item deleted successfully.";
        } else {
            echo "Error deleting item: " . mysqli_error($conn);
        }

        mysqli_stmt_close($delete_stmt);
    }

    CloseCon($conn);
} else {
    echo "Invalid request.";
}
?>
