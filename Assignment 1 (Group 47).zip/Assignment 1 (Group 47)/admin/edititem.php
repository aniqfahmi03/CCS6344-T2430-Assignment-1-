<?php
session_start();
require_once '../db_connection.php';

if (isset($_POST['edit_btn']) && isset($_POST['item_id'])) {
    $item_id = $_POST['item_id'];

    // Fetch the item details from the database based on $item_id
    $conn = OpenCon();
    $query = "SELECT LostItem_ID, User_ID, Username, Category, Item_name, Description, Location, Contact_Info, Status FROM lostitem WHERE LostItem_ID = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $item_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        // Process the fetched data
        $item_name = $row['Item_name'];
        $description = $row['Description'];
        $location = $row['Location'];
        $category = $row['Category'];
        $contact_info = $row['Contact_Info'];
        $status = $row['Status'];

        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <link rel="stylesheet" href="../css/edititem.css">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Edit Item</title>
        </head>
        <body>
            <h1>Edit Item</h1>
            <form action="updateitem.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="item_id" value="<?php echo $item_id; ?>">
                
                <label for="item_name">Item Name:</label>
                <input type="text" id="item_name" name="item_name" value="<?php echo htmlspecialchars($item_name); ?>" required>
                
                <label for="description">Description:</label>
                <textarea id="description" name="description" required><?php echo htmlspecialchars($description); ?></textarea>
                
                <label for="location">Location:</label>
                <input type="text" id="location" name="location" value="<?php echo htmlspecialchars($location); ?>" required>
                
                <label for="category">Category:</label>
                <input type="text" id="category" name="category" value="<?php echo htmlspecialchars($category); ?>" required>
                
                <label for="contact_info">Contact Info:</label>
                <input type="text" id="contact_info" name="contact_info" value="<?php echo htmlspecialchars($contact_info); ?>">
                
                <label for="status">Status:</label>
                <input type="text" id="status" name="status" value="<?php echo htmlspecialchars($status); ?>" required>
                
                <!-- Additional fields as per your table structure -->

                <button type="submit" name="update_btn">Update</button>
            </form>
        </body>
        </html>
        <?php
    } else {
        echo "Item not found."; // Handle error if item_id doesn't exist
    }

    mysqli_stmt_close($stmt);
    CloseCon($conn);
} else {
    echo "Invalid request."; // Handle if edit button wasn't clicked or item_id is missing
}
?>
