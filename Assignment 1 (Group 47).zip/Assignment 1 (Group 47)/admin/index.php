<?php
session_start();
include('../db_connection.php');

$conn = OpenCon();

if (isset($_SESSION["mySession"])) {
    $user_id = $_SESSION["mySession"];

    $result = mysqli_query($conn, "SELECT * FROM account WHERE User_ID='$user_id'");

    while ($row = mysqli_fetch_array($result)){
        $username = $row['Username'];
    }
} else {
    header('Location:../login.php');
    exit();
}

?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/user.css">
    <title>Home Page</title>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="../images/logo.jpeg" alt="L&F">
            <h1>Lost & Found</h1>
        </div>
        <nav>
        <ul>
                <li><a href="index.php">Homepage</a></li>
                <li><a href="Listprofile.php">User profile</a></li>
                <li><a href="listitems.php">Found</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="aboutus.php">About us</a></li>
                <li><a href="../logout.php">Log out</a></li>
            </ul>
        </nav>
    </div>
    <div class="main-content">
        <div class="welcome-section">
            <header>    
                <h1>Welcome <?php echo $username; ?>!</h1>
            </header>
            <h1>MMU Lost & Found.</h1>
            <p>"Reuniting Our Community, One Lost Item at a Time"</p>
        </div>
        </div>
    </div>
</body>
</html>
