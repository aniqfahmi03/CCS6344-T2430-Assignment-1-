<?php
session_start();
require_once '../db_connection.php';

$conn = OpenCon();

// Fetch all lost items from the database
$query = "SELECT LostItem_ID, User_ID, Username, Category, Item_name, Description, Location, Contact_Info, Item_image, Status FROM lostitem";
$result = mysqli_query($conn, $query);

if (!$result) {
    die('Error fetching data: ' . mysqli_error($conn));
}

CloseCon($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../css/listitems.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Lost Items </title>
    <link rel="stylesheet" href="../css/admin_listitems.css">
</head>
<body>
<div class="sidebar">
        <div class="logo">
            <img src="../images/logo.jpeg" alt="L&F">
            <h1>Lost & Found</h1>
        </div>
        <nav>
        <ul>
                <li><a href="index.php">Homepage</a></li>
                <li><a href="Listprofile.php">User profile</a></li>
                <li><a href="listitems.php">Found</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="aboutus.php">About us</a></li>
                <li><a href="../logout.php">Log out</a></li>
            </ul>
        </nav>
    </div>
    <div class="container">
        <h1>List of Lost Items</h1>
        <div class="item-list">
            <?php if (mysqli_num_rows($result) > 0) : ?>
                <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                    <div class="item-card">
                        <div class="item-image">
                            <img src="data:image/jpeg;base64,<?php echo base64_encode($row['Item_image']); ?>" alt="Item Image">
                        </div>
                        <div class="item-details">
                            <p>Posted by: <?php echo htmlspecialchars($row['Username']); ?></p>
                            <p>Category: <?php echo htmlspecialchars($row['Category']); ?></p>
                            <p>Title: <?php echo htmlspecialchars($row['Item_name']); ?></p>
                            <p>Description: <?php echo htmlspecialchars($row['Description']); ?></p>
                            <p>Location: <?php echo htmlspecialchars($row['Location']); ?></p>
                            <p>Contact Info: <?php echo htmlspecialchars($row['Contact_Info']); ?></p>
                            <p>Status: <?php echo htmlspecialchars($row['Status']); ?></p>
                        </div>
                        <div class="item-actions">
                            <form action="edititem.php" method="POST">
                                <input type="hidden" name="item_id" value="<?php echo $row['LostItem_ID']; ?>">
                                <button type="submit" name="edit_btn">Edit</button>
                            </form>
                            <form action="deleteitem.php" method="POST">
                                <input type="hidden" name="item_id" value="<?php echo $row['LostItem_ID']; ?>">
                                <button type="submit" name="delete_btn">Delete</button>
                            </form>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else : ?>
                <p>No items found.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
