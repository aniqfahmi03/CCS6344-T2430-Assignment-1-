<?php
session_start();
require_once '../db_connection.php'; 
require_once 'user.php'; 

$conn = OpenCon();
$User = new User($conn);
$users = $User->getAllUsers();
CloseCon($conn);
?>

<!DOCTYPE html>
<html lang="en">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../css/listprofile.css" />
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700&display=swap" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.7/css/all.css" rel="stylesheet">
    <title>User List</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .profile-img {
            width: 100px;
            height: 100px;
        }       
    </style>
</head>
<body>
<div class="sidebar">
        <div class="logo">
            <img src="../images/logo.jpeg" alt="L&F">
            <h1>Lost & Found</h1>
        </div>

        <nav>
        <ul>
                <li><a href="index.php">Homepage</a></li>
                <li><a href="Listprofile.php">User profile</a></li>
                <li><a href="listitems.php">Found</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="aboutus.php">About us</a></li>
                <li><a href="../logout.php">Log out</a></li>
            </ul>
        </nav>
    </div>
    <div class="content">
        <h1>User List</h1>
        <div class="table">
            <table>
                <tr>
                    <th>Number</th>
                    <th>User ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone Number</th>
                    <th>Profile Picture</th>
                    <th>Action</th>
                </tr>               
                <?php $num = 1; ?>
                <?php foreach ($users as $userData) : ?>
                    <tr>
                        <td><?php echo $num; ?></td>
                        <td><?php echo $userData['user_ID']; ?></td>
                        <td><?php echo $userData['name']; ?></td>
                        <td><?php echo $userData['email']; ?></td>
                        <td><?php echo $userData['phone_Number']; ?></td>
                        <td><?php echo "<img src='data:image/jpeg;base64," . base64_encode($userData['profilepicture']) . "' width='100px' height='100px'/>"; ?></td>
                        <td>
                        <a href="UpdateUser.php?userID=<?php echo $userData['user_ID']; ?>">Edit</a>
                        <a href="DeleteUser.php?userID=<?php echo $userData['user_ID']; ?>">Delete</a>
                        </td>
                    </tr>
                    <?php $num++; ?>
                <?php endforeach; ?>

            </table>
        </div>
    </div>
</body>
</html>
