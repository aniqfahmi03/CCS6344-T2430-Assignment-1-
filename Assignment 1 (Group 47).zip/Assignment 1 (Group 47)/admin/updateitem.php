<?php
session_start();
require_once '../db_connection.php';

if (isset($_POST['update_btn']) && isset($_POST['item_id'])) {
    $item_id = $_POST['item_id'];
    $item_name = $_POST['item_name'];
    $description = $_POST['description'];
    $location = $_POST['location'];
    $category = $_POST['category'];
    $contact_info = $_POST['contact_info'];
    $status = $_POST['status'];

    // Update the item in the database
    $conn = OpenCon();
    $query = "UPDATE lostitem SET Item_name=?, Description=?, Location=?, Category=?, Contact_Info=?, Status=? WHERE LostItem_ID=?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ssssssi", $item_name, $description, $location, $category, $contact_info, $status, $item_id);
    
    if (mysqli_stmt_execute($stmt)) {
        echo "Item updated successfully.";
    } else {
        echo "Error updating item: " . mysqli_error($conn);
    }

    mysqli_stmt_close($stmt);
    CloseCon($conn);
} else {
    echo "Invalid request.";
}
?>
