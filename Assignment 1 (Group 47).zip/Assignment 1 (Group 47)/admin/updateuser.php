<?php
session_start();
require_once '../db_connection.php'; 
require_once 'user.php'; 

$conn = OpenCon();
$User = new User($conn);

if (isset($_GET['userID'])) {
    $userID = $_GET['userID'];
    $userData = $User->getUserByID($userID);

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phoneNumber = $_POST['phone_Number'];

        $User->updateUser($userID, $name, $email, $phoneNumber);

        header('Location: listprofile.php');
        exit();
    }
} else {
    header('Location: listprofile.php');
    exit();
}

CloseCon($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../css/updateprofile.css" />
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700&display=swap" rel="stylesheet" />
    <link href="https://use.fontawesome.com/releases/v5.0.7/css/all.css" rel="stylesheet">
    <title>Update User</title>
</head>
<body>
<div class="sidebar">
    <div class="logo">
        <img src="../images/meng.jpg" alt="L&F">
        <h1>Lost & Found</h1>
    </div>

    <nav>
        <ul>
                <li><a href="index.php">Homepage</a></li>
                <li><a href="Listprofile.php">User profile</a></li>
                <li><a href="chat.php">Chat Room</a></li>
                <li><a href="listitems.php">Found</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="aboutus.php">About us</a></li>
                <li><a href="../logout.php">Log out</a></li>
        </ul>
    </nav>
</div>
<div class="content">
    <h1>Update User</h1>
    <form action="UpdateUser.php?userID=<?php echo $userID; ?>" method="post">
        <div class="form-group">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($userData['name']); ?>" required>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($userData['email']); ?>" required>
        </div>
        <div class="form-group">
            <label for="phone_Number">Phone Number</label>
            <input type="text" id="phone_Number" name="phone_Number" value="<?php echo htmlspecialchars($userData['phone_Number']); ?>" required>
        </div>
        <div class="input-container">
            <label for="profile_picture">Change Profile Picture</label>
            <input type="file" id="profile_picture" name="profile_picture" accept=".jpg, .png">
        </div>
        <button type="submit">Update</button>
    </form>
</div>
</body>
</html>
