<?php
class User {
    private $conn;
    private $table_name = "account"; // Ensure this matches your table name

    // Constructor with $db as database connection
    public function __construct($db) {
        $this->conn = $db;
    }

    // Read all users
    public function getAllUsers() {
        $query = "SELECT user_ID, name, email, phone_Number, profilepicture FROM " . $this->table_name;
        $result = $this->conn->query($query);

        if ($result->num_rows > 0) {
            $users = $result->fetch_all(MYSQLI_ASSOC);
        } else {
            $users = [];
        }

        return $users;
    }

    public function getUserByID($userID) {
        $stmt = $this->conn->prepare("SELECT user_ID, name, email, phone_Number FROM " . $this->table_name . " WHERE user_ID = ?");
        if ($stmt === false) {
            die('Prepare failed: ' . $this->conn->error);
        }
        $stmt->bind_param("i", $userID);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }

    public function updateUser($userID, $name, $email, $phoneNumber) {
        $stmt = $this->conn->prepare("UPDATE " . $this->table_name . " SET name = ?, email = ?, phone_Number = ? WHERE user_ID = ?");
        if ($stmt === false) {
            die('Prepare failed: ' . $this->conn->error);
        }
        $stmt->bind_param("sssi", $name, $email, $phoneNumber, $userID);
        $stmt->execute();
    }

    public function deleteUser($userID) {
        $stmt = $this->conn->prepare("DELETE FROM " . $this->table_name . " WHERE user_ID = ?");
        if ($stmt === false) {
            die('Prepare failed: ' . $this->conn->error);
        }
        $stmt->bind_param("i", $userID);
        $stmt->execute();
    }
}
?>

