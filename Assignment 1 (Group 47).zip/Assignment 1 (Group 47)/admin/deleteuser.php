<?php
session_start();
require_once '../db_connection.php';
require_once 'user.php';

$conn = OpenCon();
$User = new User($conn);

if (isset($_GET['userID'])) {
    $userID = $_GET['userID'];
    
    // Delete the user
    $User->deleteUser($userID);

    // Close the database connection
    CloseCon($conn);

    // Redirect to user list page
    header('Location: listprofile.php');
    exit();
} else {
    // Handle case where userID is not provided

    // Close the database connection
    CloseCon($conn);

    header('Location: listprofile.php');
    exit();
}
?>
