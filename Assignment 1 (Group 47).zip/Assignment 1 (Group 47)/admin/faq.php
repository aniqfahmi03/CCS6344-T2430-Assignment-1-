<?php
session_start();
include('../db_connection.php');

$conn = OpenCon();

// Check if the admin session is set, not the user session
if (isset($_SESSION["mySession"])) {
    $user_id = $_SESSION["mySession"];

    $result = mysqli_query($conn, "SELECT * FROM account WHERE User_ID='$user_id'");

    while ($row = mysqli_fetch_array($result)){
        $username = $row['Username'];
    }
} else {
    header('Location:../login.php');
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['add'])) {
        $question = $_POST['question'];
        $answer = $_POST['answer'];
        $sql = "INSERT INTO faq (question, answer) VALUES ('$question', '$answer')";
        mysqli_query($conn, $sql);
    } elseif (isset($_POST['update'])) {
        $id = $_POST['id'];
        $question = $_POST['question'];
        $answer = $_POST['answer'];
        $sql = "UPDATE faq SET question='$question', answer='$answer' WHERE id='$id'";
        mysqli_query($conn, $sql);
    } elseif (isset($_POST['delete'])) {
        $id = $_POST['id'];
        $sql = "DELETE FROM faq WHERE id='$id'";
        mysqli_query($conn, $sql);
    }
}

$result = mysqli_query($conn, "SELECT * FROM faq");
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/faqadmin.css">
    <title>FAQ Management</title>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="../images/logo.jpeg" alt="L&F">
            <h1>Lost & Found</h1>
        </div>
        <nav>
        <ul>
                <li><a href="index.php">Homepage</a></li>
                <li><a href="Listprofile.php">User profile</a></li>
                <li><a href="listitems.php">Found</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="aboutus.php">About us</a></li>
                <li><a href="../logout.php">Log out</a></li>
            </ul>
        </nav>
    </div>
    <div class="main-content">
        <div class="faq-section">
            <h1>Manage FAQs</h1>
            <form method="post" action="faq.php">
                <input type="hidden" name="id" id="faq-id">
                <label for="question">Question:</label>
                <input type="text" name="question" id="faq-question" required>
                <label for="answer">Answer:</label>
                <textarea name="answer" id="faq-answer" required></textarea>
                <div class="action-buttons">
                    <button type="submit" name="add">Add</button>
                    <button type="submit" name="update">Update</button>
                    <button type="submit" name="delete">Delete</button>
                </div>
            </form>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Question</th>
                            <th>Answer</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_array($result)) { ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['question']; ?></td>
                            <td><?php echo $row['answer']; ?></td>
                            <td class="action-buttons">
                                <a href="javascript:void(0);" onclick="editFAQ(<?php echo $row['id']; ?>, '<?php echo addslashes($row['question']); ?>', '<?php echo addslashes($row['answer']); ?>')">Edit</a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script>
        function editFAQ(id, question, answer) {
            document.getElementById('faq-id').value = id;
            document.getElementById('faq-question').value = question;
            document.getElementById('faq-answer').value = answer;
        }

        function deleteFAQ(id) {
            if (confirm('Are you sure you want to delete this FAQ?')) {
                document.getElementById('faq-id').value = id;
                document.querySelector('button[name="delete"]').click();
            }
        }
    </script>
</body>
</html>
