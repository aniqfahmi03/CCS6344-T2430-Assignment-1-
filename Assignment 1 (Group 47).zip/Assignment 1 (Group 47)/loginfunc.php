<?php
session_start();
include('db_connection.php');
$conn = OpenCon();

// Set the max number of allowed attempts and the cooldown period (in seconds)
$max_attempts = 5;
$cooldown_time = 300; // 5 minutes

// Check if the login form was submitted
if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Initialize or update session variables for failed attempts
    if (!isset($_SESSION['failed_attempts'])) {
        $_SESSION['failed_attempts'] = 0;
        $_SESSION['last_failed_attempt'] = time();
    }

    // Check if the user is currently in a cooldown period
    if ($_SESSION['failed_attempts'] >= $max_attempts) {
        $time_diff = time() - $_SESSION['last_failed_attempt'];
        if ($time_diff < $cooldown_time) {
            $remaining_time = $cooldown_time - $time_diff;
            echo "<script>alert('Too many failed attempts. Try again in $remaining_time seconds.'); window.location.href='login.php';</script>";
            exit();
        } else {
            // Reset failed attempts after cooldown period
            $_SESSION['failed_attempts'] = 0;
        }
    }

    // Query the database for user authentication
    $sql = "SELECT * FROM account WHERE Username='$username' AND Password='$password'";
    $result = mysqli_query($conn, $sql);
    $rowcount = mysqli_num_rows($result);

    // Check if login is successful
    if ($rowcount == 1) {
        $row = mysqli_fetch_array($result);
        $_SESSION["mySession"] = $row["User_ID"];
        $_SESSION['failed_attempts'] = 0; // Reset failed attempts on successful login

        // Check user role and redirect
        $userRole = $row['Role'];
        if ($userRole === 'Admin') {
            header('Location:admin/index.php');
        } else if ($userRole === 'User') {
            header('Location:user/index.php');
        }
    } else {
        // Increment failed attempts and update the last failed attempt timestamp
        $_SESSION['failed_attempts']++;
        $_SESSION['last_failed_attempt'] = time();
        
        echo "<script>alert('Username / password not found!'); window.location.href='login.php';</script>";
    }
}

CloseCon($conn);
?>
