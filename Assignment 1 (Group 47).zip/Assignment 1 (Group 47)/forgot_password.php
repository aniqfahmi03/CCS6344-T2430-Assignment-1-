<?php
// Include necessary files
require_once ('db_connection.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="css/forgot_password.css">
</head>
<body>
    <div class="container">
        <?php
        // Check if form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
            $conn = OpenCon();

            // Sanitize input
            $username = mysqli_real_escape_string($conn, $_POST['username']);

            // Check if username exists in database
            $sql = "SELECT * FROM account WHERE Username = '$username'";
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) == 1) {
                $row = mysqli_fetch_assoc($result);
                $recovery_question = $row['recovery_question'];

                // Display recovery question and input for answer
                echo '<form action="reset_password.php" method="post">';
                echo '<h2>Security Question:</h2>';
                echo '<p>' . $recovery_question . '</p>';
                echo '<input type="hidden" name="username" value="' . $username . '">';
                echo '<label for="recovery_answer">Your Answer:</label>';
                echo '<input type="text" id="recovery_answer" name="recovery_answer" required>';
                echo '<button type="submit" name="submit">Submit Answer</button>';
                echo '</form>';
            } else {
                echo '<div class="error">User not found.</div>';
            }

            CloseCon($conn);
        } else {
            // Display form to input username
            echo '<form action="" method="post">';
            echo '<label for="username">Enter your username:</label>';
            echo '<input type="text" id="username" name="username" required>';
            echo '<button type="submit" name="submit">Submit</button>';
            echo '</form>';
        }
        ?>
    </div>
</body>
</html>
