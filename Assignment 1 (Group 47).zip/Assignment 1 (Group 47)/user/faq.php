<?php
session_start();
include('../db_connection.php');

$conn = OpenCon();

// Check if the admin session is set, not the user session
if (isset($_SESSION["mySession"])) {
    $user_id = $_SESSION["mySession"];

    $result = mysqli_query($conn, "SELECT * FROM account WHERE User_ID='$user_id'");

    while ($row = mysqli_fetch_array($result)) {
        $username = $row['Username'];
    }
} else {
    header('Location: ../login.php');
    exit();
}

$faqResult = mysqli_query($conn, "SELECT * FROM faq");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/faq.css">
    <title>FAQ Management</title>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="../images/logo.jpeg" alt="L&F">
            <h1>Lost & Found</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Homepage</a></li>
                <li><a href="userprofile.php">User profile</a></li>
                <li><a href="chat.php">Chat Room</a></li>
                <li><a href="found.php">Found</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="about.php">About us</a></li>
                <li><a href="../logout.php">Log out</a></li>
            </ul>
        </nav>
    </div>
    <div class="table-container">
        <h1>Frequently Ask Question (FAQ)</h1>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Question</th>
                    <th>Answer</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_array($faqResult)) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['question']; ?></td>
                    <td><?php echo $row['answer']; ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>