<?php
session_start();
include('../db_connection.php');

if (!isset($_SESSION['mySession'])) {
    echo '<p>You are not logged in.</p>';
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['mySession'];
    $item_id = $_POST['item_id'];

    $conn = OpenCon();

    $query = "INSERT INTO item_claims (LostItem_ID, Claimant_User_ID) VALUES ('$item_id', '$user_id')";

    if (mysqli_query($conn, $query)) {
        echo '<p>Claim request submitted successfully.</p>';
    } else {
        echo '<p>Error: ' . mysqli_error($conn) . '</p>';
    }

    CloseCon($conn);
    header('Location: found.php');
    exit;
}
?>
