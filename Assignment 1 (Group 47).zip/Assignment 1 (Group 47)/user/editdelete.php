<?php
session_start(); // Start session to get user ID
include('../db_connection.php'); // Include database connection script

if (!isset($_SESSION['mySession'])) {
    echo '<p>You are not logged in.</p>';
    exit; // Stop further execution if not logged in
}

$user_id = $_SESSION['mySession']; 

// Open a connection to the database
$conn = OpenCon();

// Check if ID parameter exists in the URL
if (isset($_GET['id'])) {
    $item_id = $_GET['id'];
    
    // Check if the user owns this item
    $query = "SELECT * FROM lostitem WHERE Lostitem_ID = '$item_id' AND User_ID = '$user_id'";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        die('Error fetching item data: ' . mysqli_error($conn));
    }

    // If the item belongs to the user, proceed with edit or delete
    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        
        if (isset($_POST['edit'])) {
            // Handle edit action
            $category = mysqli_real_escape_string($conn, $_POST['category']);
            $title = mysqli_real_escape_string($conn, $_POST['title']);
            $place = mysqli_real_escape_string($conn, $_POST['place']);
            $description = mysqli_real_escape_string($conn, $_POST['description']);
            $contact = mysqli_real_escape_string($conn, $_POST['contact']);
            $date = mysqli_real_escape_string($conn, $_POST['date']);
            
            // Update the item in the database
            $update_query = "UPDATE lostitem SET 
                            Category = '$category', 
                            Item_name = '$title', 
                            Description = '$description', 
                            Location = '$place', 
                            Contact_Info = '$contact', 
                            Date_Found = '$date' 
                            WHERE Lostitem_ID = '$item_id'";

            if (mysqli_query($conn, $update_query)) {
                // Redirect after update
                header('Location: itemlisted.php');
                exit;
            } else {
                echo '<p>Error updating item: ' . mysqli_error($conn) . '</p>';
            }
        } elseif (isset($_POST['delete'])) {
            // Handle delete action
            $delete_query = "DELETE FROM lostitem WHERE Lostitem_ID = '$item_id'";
            
            if (mysqli_query($conn, $delete_query)) {
                // Redirect after delete
                header('Location: itemlisted.php');
                exit;
            } else {
                echo '<p>Error deleting item: ' . mysqli_error($conn) . '</p>';
            }
        }

        // Display the edit form
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Edit/Delete Item</title>
            <link rel="stylesheet" href="../css/editdelete.css"> <!-- Assuming styles are in styles.css -->
        </head>
        <body>
            <div class="container">
                <h1>Edit/Delete Item</h1>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?id=' . $item_id; ?>" method="post">
                    <div class="form-group">
                        <label for="category">Category:</label>
                        <input type="text" id="category" name="category" value="<?php echo htmlspecialchars($row['Category']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="title">Title:</label>
                        <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($row['Item_name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="place">Place found:</label>
                        <input type="text" id="place" name="place" value="<?php echo htmlspecialchars($row['Location']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="description">Description:</label>
                        <textarea id="description" name="description" required><?php echo htmlspecialchars($row['Description']); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="contact">Contact Info:</label>
                        <input type="text" id="contact" name="contact" value="<?php echo htmlspecialchars($row['Contact_Info']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="date">Date:</label>
                        <input type="date" id="date" name="date" value="<?php echo htmlspecialchars($row['Date_Found']); ?>" required>
                    </div>
                    <div class="form-group">
                        <button type="submit" name="edit">Update</button>
                        <button type="submit" name="delete">Delete</button>
                    </div>
                </form>
            </div>
            <div class="sidebar">
                <nav>
                    <ul>
                        <li><a href="index.php">Homepage</a></li>
                        <li><a href="userprofile.php">User profile</a></li>
                        <li><a href="chat.php">Chat Room</a></li>
                        <li><a href="found.php">Found</a></li>
                        <li><a href="faq.php">FAQ</a></li>
                        <li><a href="about.php">About us</a></li>
                        <li><a href="../logout.php">Log out</a></li>
                    </ul>
                </nav>
            </div>
        </body>
        </html>
        <?php

    } else {
        echo '<p>Item not found or you do not have permission to edit/delete this item.</p>';
    }
} else {
    echo '<p>No item ID specified.</p>';
}

// Close the database connection
CloseCon($conn);
?>
