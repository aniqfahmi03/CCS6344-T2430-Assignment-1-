<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>List of Your Items</title>
    <link rel="stylesheet" href="../css/itemlisted.css"> <!-- Assuming styles are in styles.css -->
</head>
<body>
    <div class="container">
        <h1>List of Your Items</h1>
        <?php
        session_start(); // Start session to get user ID
        include('../db_connection.php'); // Include database connection script

        if (!isset($_SESSION['mySession'])) {
            echo '<p>You are not logged in.</p>';
            exit; // Stop further execution if not logged in
        }

        $user_id = $_SESSION['mySession']; 

        // Open a connection to the database
        $conn = OpenCon();

        // Query to retrieve all items listed by the user
        $query = "SELECT Lostitem_ID, Category, Item_name, Description, Location, Date_Found, Contact_Info
                  FROM lostitem
                  WHERE User_ID = '$user_id' AND Status = 'Unclaimed'"; // Assuming 'Unclaimed' is the status for items not yet claimed

        // Perform the query
        $result = mysqli_query($conn, $query);

        if (!$result) {
            die('Error fetching data: ' . mysqli_error($conn));
        }

        // Check if there are rows returned
        if (mysqli_num_rows($result) > 0) {
            // Display the table header
            echo '<table>';
            echo '<tr>';
            echo '<th>Lostitem ID</th>';
            echo '<th>Category</th>';
            echo '<th>Item Name</th>';
            echo '<th>Description</th>';
            echo '<th>Location</th>';
            echo '<th>Date Found</th>';
            echo '<th>Contact Info</th>';
            echo '<th>Actions</th>';
            echo '</tr>';

            // Output data of each row
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<tr>';
                echo '<td>' . htmlspecialchars($row['Lostitem_ID']) . '</td>';
                echo '<td>' . htmlspecialchars($row['Category']) . '</td>';
                echo '<td>' . htmlspecialchars($row['Item_name']) . '</td>';
                echo '<td>' . htmlspecialchars($row['Description']) . '</td>';
                echo '<td>' . htmlspecialchars($row['Location']) . '</td>';
                echo '<td>' . htmlspecialchars($row['Date_Found']) . '</td>';
                echo '<td>' . htmlspecialchars($row['Contact_Info']) . '</td>';
                echo '<td>';
                echo '<a href="editdelete.php?id=' . htmlspecialchars($row['Lostitem_ID']) . '">Edit</a> | ';
                echo '<a href="editdelete.php?id=' . htmlspecialchars($row['Lostitem_ID']) . '&action=delete">Delete</a>';
                echo '</td>';
                echo '</tr>';
            }

            // Close the table
            echo '</table>';
        } else {
            echo '<p>No items found.</p>';
        }

        // Close the database connection
        CloseCon($conn);
        ?>
    </div>
    <div class="sidebar">
        <nav>
            <ul>
                <li><a href="index.php">Homepage</a></li>
                <li><a href="userprofile.php">User profile</a></li>
                <li><a href="chat.php">Chat Room</a></li>
                <li><a href="found.php">Found</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="about.php">About us</a></li>
                <li><a href="../logout.php">Log out</a></li>
            </ul>
        </nav>
    </div>
</body>
</html>
