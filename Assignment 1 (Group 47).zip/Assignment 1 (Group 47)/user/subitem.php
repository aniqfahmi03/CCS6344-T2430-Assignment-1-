<!DOCTYPE html>
<html lang="en">
<head>
    <title>Post Found Item</title>
    <link rel="stylesheet" href="../css/subitem.css">
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="../images/logo.jpeg" alt="L&F">
            <h1>Lost & Found</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Homepage</a></li>
                <li><a href="userprofile.php">User profile</a></li>
                <li><a href="chat.php">Chat Room</a></li>
                <li><a href="found.php">Found</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="about.php">About us</a></li>
                <li><a href="../logout.php">Log out</a></li>
            </ul>
        </nav>
    </div>
    <div class="main-content">
        <h1>Post found item</h1>
        <p>Add an item you found and its details. Please fill all the required fields:</p>
        <?php
        session_start();
        include('../db_connection.php');

        $conn = OpenCon();

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $category = $_POST['category'];
            $title = $_POST['title'];
            $place = $_POST['place'];
            $description = $_POST['description'];
            $contact = $_POST['contact'];
            $date = $_POST['date'];
            $image = $_FILES['image']['tmp_name'];

            $user_id = $_SESSION["mySession"];

            // Retrieve the username from the account table
            $username_query = "SELECT username FROM account WHERE User_ID = '$user_id'";
            $username_result = mysqli_query($conn, $username_query);
            if ($username_result && mysqli_num_rows($username_result) > 0) {
                $username_row = mysqli_fetch_assoc($username_result);
                $username = $username_row['username'];
            } else {
                $username = 'Unknown'; // Default value in case username is not found
            }

            // Prepare image for database insertion
            $imageData = file_get_contents($image);
            $escapedImage = mysqli_real_escape_string($conn, $imageData);

            // Insert found item into database
            $query = "INSERT INTO lostitem (User_ID, Username, Category, Item_name, Description, Location, Date_Found, Contact_Info, Status, Item_image)
                      VALUES ('$user_id', '$username', '$category', '$title', '$description', '$place', '$date', '$contact', 'Unclaimed', '$escapedImage')";

            if (mysqli_query($conn, $query)) {
                echo '<div class="success-message">Item successfully posted!</div>';
                // Redirect or handle success as needed
            } else {
                echo '<div class="error-message">Error: ' . $query . '<br>' . mysqli_error($conn) . '</div>';
            }
        }

        CloseCon($conn);
        ?>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="category">Category:</label>
                <select id="category" name="category" required>
                    <option value="">Please select</option>
                    <option value="Personal Items">Personal Items (Eg. wallets, keys, phones, and jewelry)</option>
                    <option value="Electronics">Electronics (Eg. laptops, tablets, cameras, and headphones)</option>
                    <option value="Clothing and Accessories">Clothing and Accessories (Eg. jackets, bags, hats, and scarves)</option>
                    <option value="Documents and IDs">Documents and IDs (Eg. Important papers, passports, driver's licenses)</option>
                </select>
            </div>
            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" id="title" name="title" required>
            </div>
            <div class="form-group">
                <label for="place">Place found:</label>
                <select id="place" name="place" required>
                    <option value="">Please select</option>
                    <option value="FCI Building">FCI Building</option>
                    <option value="FCM Building">FCM Building</option>
                    <option value="FOE Building">FOE Building</option>
                    <option value="FOM Building">FOM Building</option>
                    <option value="DTC Building">DTC Building</option>
                    <option value="Starbees & MMU Stadium">Starbees & MMU Stadium</option>
                    <option value="MMU Cyber Park">MMU Cyber Park</option>
                    <option value="Hostel Building HB1, HB2, HB3, HB4">Hostel Building HB1, HB2, HB3, HB4</option>
                    <option value="Learning Point & SHD Library">Learning Point & SHD Library</option>
                    <option value="Surau Al Hidayah">Surau Al Hidayah</option>
                    <option value="Central Lecture Complex">Central Lecture Complex</option>
                    <option value="STAD Building">STAD Building</option>
                </select>
            </div>
            <div class="form-group">
                <label for="description">Description:</label>
                <textarea id="description" name="description" required></textarea>
            </div>
            <div class="form-group">
                <label for="contact">Contact Info:</label>
                <input type="text" id="contact" name="contact" required>
           </div>
            <div class="form-group">
                <label for="date">Date:</label>
                <input type="date" id="date" name="date" required>
            </div>
            <div class="form-group">
                <label for="image">Item image:</label>
                <input type="file" id="image" name="image" required accept="image/*">
            </div>
            <div class="form-group">
                <button type="submit">Submit</button>
            </div>
        </form>
    </div>
</body>
</html>
