<?php
session_start();
include('../db_connection.php');

if (!isset($_SESSION['mySession'])) {
    echo '<p>You are not logged in.</p>';
    exit;
}

$user_id = $_SESSION['mySession'];
$category = isset($_GET['category']) ? $_GET['category'] : 'all';
$location = isset($_GET['location']) ? $_GET['location'] : 'all';

$conn = OpenCon();

// Construct SQL query for fetching lost items
$query = "SELECT LostItem_ID, Username, Category, Item_name, Description, Location, Contact_Info, Item_image, User_ID
          FROM lostitem WHERE Status='Unclaimed'";

// Add filters based on category and location if they are not 'all'
$params = [];
if ($category !== 'all') {
    $query .= " AND Category = ?";
    $params[] = $category;
}
if ($location !== 'all') {
    $query .= " AND Location = ?";
    $params[] = $location;
}

$stmt = $conn->prepare($query);
if (!empty($params)) {
    $types = str_repeat('s', count($params));
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>List of Lost Items</title>
    <link rel="stylesheet" href="../css/found.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="../images/Lost-and-found_logo.jpg" alt="L&F">
            <p>Lost & Found</p>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Homepage</a></li>
                <li><a href="userprofile.php">User profile</a></li>
                <li><a href="chat.php">Chat Room</a></li>
                <li><a href="found.php">Found</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="about.php">About us</a></li>
                <li><a href="../logout.php">Log out</a></li>
            </ul>
        </nav>
    </div>
    <div class="container">
        <h1>Lost Items</h1>
        <form class="search-form" action="found.php" method="GET">
            <label for="category">Category:</label>
            <select id="category" name="category">
                <option value="all">All</option>
                <option value="electronics">Electronics</option>
                <option value="Personal Items">Personal Items</option>
                <option value="Clothing and Accessories">Clothing and Accessories</option>
                <option value="Documents and IDs">Documents and IDs</option>
            </select>
            <label for="location">Location:</label>
            <select id="location" name="location">
                <option value="all">All</option>
                <option value="FCI Building">FCI Building</option>
                <option value="FCM Building">FCM Building</option>
                <option value="FOE Building">FOE Building</option>
                <option value="FOM Building">FOM Building</option>
                <option value="DTC Building">DTC Building</option>
                <option value="Starbees & MMU Stadium">Starbees & MMU Stadium</option>
                <option value="MMU Cyber Park">MMU Cyber Park</option>
                <option value="Hostel Building HB1, HB2, HB3, HB4">Hostel Building HB1, HB2, HB3, HB4</option>
                <option value="Learning Point & SHD Library">Learning Point & SHD Library</option>
                <option value="Surau Al Hidayah">Surau Al Hidayah</option>
                <option value="Central Lecture Complex">Central Lecture Complex</option>
                <option value="STAD Building">STAD Building</option>
            </select>
            <button type="submit">Submit</button>
        </form>

        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="item-card">';
                echo '<div class="item-image"><img src="data:image/jpeg;base64,' . base64_encode($row['Item_image']) . '" alt="Item Image"></div>';
                echo '<div class="item-details">';
                echo '<p>Posted by: ' . htmlspecialchars($row['Username']) . '</p>';
                echo '<p>Category: ' . htmlspecialchars($row['Category']) . '</p>';
                echo '<p>Title: ' . htmlspecialchars($row['Item_name']) . '</p>';
                echo '<p>Description: ' . htmlspecialchars($row['Description']) . '</p>';
                echo '<p>Location: ' . htmlspecialchars($row['Location']) . '</p>';
                echo '<p>Contact Info: ' . htmlspecialchars($row['Contact_Info']) . '</p>';
                echo '</div>';
                echo '<div class="item-actions">';
                echo '<form action="claimitem.php" method="POST">';
                echo '<input type="hidden" name="item_id" value="' . htmlspecialchars($row['LostItem_ID']) . '">';
                echo '<button class="claim-button" type="submit">Claim</button>';
                echo '</form>';
                echo '</div>';
                echo '</div>';
            }
        } else {
            echo '<p>No items found.</p>';
        }

        $stmt->close();
        CloseCon($conn);
        ?>
    </div>
</body>
</html>
