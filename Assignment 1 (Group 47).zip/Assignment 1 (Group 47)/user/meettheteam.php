<?php
session_start();
include('../db_connection.php');

$conn = OpenCon();

if (isset($_SESSION["mySession"])) {
    $user_id = $_SESSION["mySession"];

    $result = mysqli_query($conn, "SELECT * FROM account WHERE User_ID='$user_id'");

    while ($row = mysqli_fetch_array($result)){
        $username = $row['Username'];
    }
} else {
    header('Location:../login.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/meettheteam.css">
    <title>Meet the Team</title>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="../images/Lost-and-found_logo.jpg" alt="L&F">
            <h1>Lost & Found</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Homepage</a></li>
                <li><a href="userprofile.php">User profile</a></li>
                <li><a href="chat.php">Chat Room</a></li>
                <li><a href="found.php">Found</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="about.php">About us</a></li>
                <li><a href="../logout.php">Log out</a></li>
            </ul>
        </nav>
    </div>
    <div class="main-content">
        <div class="team-section">
            <h1>Meet the team.</h1>
            <div class="team-member">
                <img src="../images/aiman.jpeg" alt="Aiman">
                <div class="member-info">
                    <h3>Aiman</h3>
                    <p class="position">Student ID: 1211101303</p>
                    <p class="section">Section: TC1L</p>
                    <p class="contact"><a href="mailto:aiman@example.com">1211101303@student.mmu.edu</a></p>
                </div>
            </div>
            <div class="team-member">
                <img src="../images/luqman.jpeg" alt="Luqman">
                <div class="member-info">
                    <h3>Luqman</h3>
                    <p class="position">Student ID: 1221303795</p>
                    <p class="section">Section: TC1L</p>
                    <p class="contact"><a href="mailto:luqman@example.com">1221303795@student.mmu.edu</a></p>
                </div>
            </div>
            <div class="team-member">
                <img src="../images/aniq.jpeg" alt="Aniq">
                <div class="member-info">
                    <h3>Aniq</h3>
                    <p class="position">Student ID: 1211102269</p>
                    <p class="section">Section: TC1L</p>
                    <p class="contact"><a href="mailto:aniq@example.com">1211102269@student.mmu.edu</a></p>
                </div>
            </div>
            <div class="team-member">
                <img src="../images/ilham.jpeg" alt="Ilham">
                <div class="member-info">
                    <h3>Ilham</h3>
                    <p class="position">Student ID: 1211103797</p>
                    <p class="section">Section: TC1L</p>
                    <p class="contact"><a href="mailto:ilham@example.com">1211103797@student.mmu.edu</a></p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
