<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pending Item Approvals</title>
    <link rel="stylesheet" href="../css/pendingitem.css">
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="../images/logo.jpeg" alt="Logo">
            <p>Website Name</p>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Homepage</a></li>
                <li><a href="userprofile.php">User profile</a></li>
                <li><a href="chat.php">Chat Room</a></li>
                <li><a href="found.php">Found</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="about.php">About us</a></li>
                <li><a href="../logout.php">Log out</a></li>
            </ul>
        </nav>
    </div>
    <div class="container">
        <h1>Pending Item Approvals</h1>
        <?php
        session_start();
        include('../db_connection.php');

        if (!isset($_SESSION['mySession'])) {
            echo '<p>You are not logged in.</p>';
            exit;
        }

        $user_id = $_SESSION['mySession'];

        $conn = OpenCon();

        // Fetch pending claims for items the user has posted
        $query = "SELECT ic.Claim_ID, ic.LostItem_ID, ic.Claimant_User_ID, a.Username, li.Item_name, li.Description, li.Location, li.Date_Found
                  FROM item_claims ic
                  JOIN lostitem li ON ic.LostItem_ID = li.LostItem_ID
                  JOIN account a ON ic.Claimant_User_ID = a.User_ID
                  WHERE li.User_ID = '$user_id' AND ic.Claim_Status = 'Pending'";

        $result = mysqli_query($conn, $query);

        if (!$result) {
            die('Error fetching data: ' . mysqli_error($conn));
        }

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<div class="claim-card">';
                echo '<p>Claimant: ' . htmlspecialchars($row['Username']) . '</p>';
                echo '<p>Item: ' . htmlspecialchars($row['Item_name']) . '</p>';
                echo '<p>Description: ' . htmlspecialchars($row['Description']) . '</p>';
                echo '<p>Location: ' . htmlspecialchars($row['Location']) . '</p>';
                echo '<p>Date Found: ' . htmlspecialchars($row['Date_Found']) . '</p>';
                echo '<form action="updateclaim.php" method="POST">';
                echo '<input type="hidden" name="claim_id" value="' . $row['Claim_ID'] . '">';
                echo '<button name="action" value="approve" type="submit">Approve</button>';
                echo '<button name="action" value="reject" type="submit">Reject</button>';
                echo '</form>';
                echo '</div>';
            }
        } else {
            echo '<p>No pending claims found.</p>';
        }

        // Fetch approved claims to be returned
        $query = "SELECT ic.Claim_ID, ic.LostItem_ID, ic.Claimant_User_ID, a.Username, li.Item_name, li.Description, li.Location, li.Date_Found
                  FROM item_claims ic
                  JOIN lostitem li ON ic.LostItem_ID = li.LostItem_ID
                  JOIN account a ON ic.Claimant_User_ID = a.User_ID
                  WHERE li.User_ID = '$user_id' AND ic.Claim_Status = 'Approved'";

        $result = mysqli_query($conn, $query);

        if (!$result) {
            die('Error fetching data: ' . mysqli_error($conn));
        }

        if (mysqli_num_rows($result) > 0) {
            echo '<h2>Items to be Returned</h2>';
            while ($row = mysqli_fetch_assoc($result)) {
                echo '<div class="claim-card">';
                echo '<p>Claimant: ' . htmlspecialchars($row['Username']) . '</p>';
                echo '<p>Item: ' . htmlspecialchars($row['Item_name']) . '</p>';
                echo '<p>Description: ' . htmlspecialchars($row['Description']) . '</p>';
                echo '<p>Location: ' . htmlspecialchars($row['Location']) . '</p>';
                echo '<p>Date Found: ' . htmlspecialchars($row['Date_Found']) . '</p>';
                echo '</div>';
            }
        } else {
            echo '<p>No items to be returned.</p>';
        }

        CloseCon($conn);
        ?>
    </div>
</body>
</html>
