<?php
session_start();
include('../db_connection.php');

$conn = OpenCon();

if(isset($_SESSION["mySession"])){
    $user_id = $_SESSION["mySession"];

    $result = mysqli_query($conn, "SELECT * FROM account WHERE User_ID='$user_id'");

    while ($row = mysqli_fetch_array($result)){
        $username = $row['Username'];
        $name = $row['name'];
        $email = $row['Email'];
        $phone_number = $row['Phone_Number']; 
        $profile_picture = $row['ProfilePicture']; 
    }
}
else {
    header('Location:../login.php');
    exit();
}

function displayProfilePicture($profile_picture) {
    if ($profile_picture) {
        echo '<img src="data:image/jpeg;base64,'.base64_encode($profile_picture).'" alt="Profile Picture">';
    } else {
        echo '<img src="../images/default-profile.jpg" alt="Default Profile Picture">';
    }
}
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="../css/userprofile.css">
        <title>User Profile</title>
    </head>
    <body>
    <div class="sidebar">
        <nav>
            <ul>
                <li><a href="index.php">Homepage</a></li>
                <li><a href="userprofile.php">User profile</a></li>
                <li><a href="chat.php">Chat Room</a></li>
                <li><a href="found.php">Found</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="about.php">About us</a></li>
                <li><a href="../logout.php">Log out</a></li>
            </ul>
        </nav>
    </div>
        <div class="container">
            <section class="profile">
                <div class="profile-picture">
                    <?php displayProfilePicture($profile_picture); ?>
                </div>
                <div class="profile-details">
                    <h2><?php echo $name; ?></h2>
                    <p><strong>Username:</strong> <?php echo $username; ?></p>
                    <p><strong>Email:</strong> <?php echo $email; ?></p>
                    <p><strong>Phone Number:</strong> <?php echo $phone_number; ?></p>
                </div>
            </section>
            <section class="edit-profile">
                <h2>Edit Profile</h2>
                <form action="../updateprofile.php" method="post" enctype="multipart/form-data">
                    <div class="input-container">
                        <label for="name">Name</label>
                        <input type="text" id="name" name="name" value="<?php echo $name; ?>" required>
                    </div>
                    <div class="input-container">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" value="<?php echo $email; ?>" required>
                    </div>
                    <div class="input-container">
                        <label for="phone_number">Phone Number</label>
                        <input type="text" id="phone_number" name="phone_number" value="<?php echo $phone_number; ?>" required>
                    </div>
                    <div class="input-container">
                        <label for="profile_picture">Change Profile Picture</label>
                        <input type="file" id="profile_picture" name="profile_picture" accept=".jpg, .png">
                    </div>
                    <button type="submit" name="update_profile" class="update-btn">Update Profile</button>
                </form>
                <h2>Change Password</h2>
                <form action="../updateprofile.php" method="post">
                    <div class="input-container">
                        <label for="current_password">Current Password</label>
                        <div class="password-wrapper">
                            <input type="password" id="current_password" name="current_password" required>
                            <img src="https://media.geeksforgeeks.org/wp-content/uploads/20210917145551/eye.png" width="24" height="24" id="toggleCurrentPassword">
                        </div>
                    </div>
                    <div class="input-container">
                        <label for="new_password">New Password</label>
                        <div class="password-wrapper">
                            <input type="password" id="new_password" name="new_password" required>
                            <img src="https://media.geeksforgeeks.org/wp-content/uploads/20210917145551/eye.png" width="24" height="24" id="toggleNewPassword">
                        </div>
                    </div>
                    <div class="input-container">
                        <label for="confirm_password">Confirm New Password</label>
                        <div class="password-wrapper">
                            <input type="password" id="confirm_password" name="confirm_password" required>
                            <img src="https://media.geeksforgeeks.org/wp-content/uploads/20210917145551/eye.png" width="24" height="24" id="toggleConfirmPassword">
                        </div>
                    </div>
                    <button type="submit" name="update_password" class="update-btn">Update Password</button>
                </form>
            </section>
        </div>
        <script>
            // Toggle password visibility function
            function togglePasswordVisibility(toggleId, targetId) {
                const togglePassword = document.querySelector(toggleId);
                const password = document.querySelector(targetId);

                togglePassword.addEventListener('click', function () {
                    // Toggle the type attribute
                    const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
                    password.setAttribute('type', type);

                    // Toggle the eye slash icon
                    if (togglePassword.src.match("https://media.geeksforgeeks.org/wp-content/uploads/20210917150049/eyeslash.png")) {
                        togglePassword.src = "https://media.geeksforgeeks.org/wp-content/uploads/20210917145551/eye.png";
                    } else {
                        togglePassword.src = "https://media.geeksforgeeks.org/wp-content/uploads/20210917150049/eyeslash.png";
                    }
                });
            }

            togglePasswordVisibility('#toggleCurrentPassword', '#current_password');
            togglePasswordVisibility('#toggleNewPassword', '#new_password');
            togglePasswordVisibility('#toggleConfirmPassword', '#confirm_password');
        </script>
    </body>
</html>
