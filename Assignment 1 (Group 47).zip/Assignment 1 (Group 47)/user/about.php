<?php
session_start();
include('../db_connection.php');

$conn = OpenCon();

if (isset($_SESSION["mySession"])) {
    $user_id = $_SESSION["mySession"];

    $result = mysqli_query($conn, "SELECT * FROM account WHERE User_ID='$user_id'");

    while ($row = mysqli_fetch_array($result)){
        $username = $row['Username'];
    }
} else {
    header('Location:../login.php');
    exit();
}

?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/about.css">
    <title>Home Page</title>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="../images/logo.jpeg" alt="L&F">
            <h1>Lost & Found</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Homepage</a></li>
                <li><a href="userprofile.php">User profile</a></li>
                <li><a href="chat.php">Chat Room</a></li>
                <li><a href="found.php">Found</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="about.php">About us</a></li>
                <li><a href="../logout.php">Log out</a></li>
            </ul>
        </nav>
    </div>
    <div class="main-content">
        <div class="welcome-section">
            <header>    
            </header>
            <h1>About us.</h1>
            <p>"We are a dedicated team of Multimedia University students committed
                 to helping our community. 
                Our mission is to create a reliable and efficient platform
                 where students, staff, and lecturers 
                can report and recover lost items. By bridging the gap between those who have lost items and those 
                who have found them, we aim to foster a sense of community 
                and mutual assistance within our university."</p>
            <h1>Our goals.</h1>
            <p>"Our mission to streamline the reporting and recovery of lost items within our community. 
                Our goal is to foster unity and mutual support among students, staff, and lecturers by providing
                 a reliable platform for efficient item retrieval. By bridging the gap between those who have lost
                  items and those who have found them, we aim to cultivate a culture of responsibility and assistance 
                  on campus, promoting a sense of community and collective well-being."</p>
        </div>
        <a href="meettheteam.php" class="meet-team-button">Meet the Team</a>
        </div>
    </div>
</body>
</html>