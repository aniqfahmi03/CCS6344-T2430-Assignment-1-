<?php
session_start();
include('../db_connection.php');

$conn = OpenCon();

if (!isset($_SESSION["mySession"])) {
    header('Location:../login.php');
    exit();
}

$user_id = $_SESSION["mySession"];
$result = mysqli_query($conn, "SELECT * FROM account WHERE User_ID='$user_id'");

while ($row = mysqli_fetch_array($result)) {
    $username = $row['Username'];
}

// Handle user search form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search_username'])) {
    $search_username = mysqli_real_escape_string($conn, $_POST['search_username']);

    // Query to search for users with 'User' role
    $search_query = "SELECT * FROM account WHERE Username LIKE '%$search_username%' AND User_ID != '$user_id' AND Role = 'User'";
    $search_result = mysqli_query($conn, $search_query);

    if (!$search_result) {
        die("Error searching for users: " . mysqli_error($conn));
    }
}

// Handle sending messages
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message']) && isset($_POST['receiver_id'])) {
    $message = mysqli_real_escape_string($conn, $_POST['message']);
    $receiver_id = mysqli_real_escape_string($conn, $_POST['receiver_id']);

    $query = "INSERT INTO messages (Sender_ID, Receiver_ID, Message_Text) VALUES ('$user_id', '$receiver_id', '$message')";
    mysqli_query($conn, $query);
}

// Query to get all users with 'User' role for listing and searching
$users_result = mysqli_query($conn, "SELECT * FROM account WHERE User_ID != '$user_id' AND Role = 'User'");
$messages_result = mysqli_query($conn, "SELECT m.*, a1.Username AS SenderName, a2.Username AS ReceiverName FROM messages m 
                                         JOIN account a1 ON m.Sender_ID = a1.User_ID 
                                         JOIN account a2 ON m.Receiver_ID = a2.User_ID 
                                         WHERE Sender_ID = '$user_id' OR Receiver_ID = '$user_id' 
                                         ORDER BY Timestamp DESC");
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/chat.css">
    <title>Chat Room</title>
</head>
<body>
<div class="container">
    <header>
        <h1>Welcome <?php echo $username; ?>!</h1>
        <p>Chat with other users.</p>
    </header>
    <section class="search">
        <h2>Search Users</h2>
        <form method="post" action="chat.php">
            <input type="text" name="search_username" placeholder="Enter username">
            <button type="submit">Search</button>
        </form>
    </section>
    <section class="users">
        <h2>Users</h2>
        <ul>
            <?php
            if (isset($search_result)) {
                // Display search results
                while ($user = mysqli_fetch_array($search_result)) {
                    echo '<li data-user-id="' . $user['User_ID'] . '">' . $user['Username'] . '</li>';
                }
            } else {
                // Display all users with 'User' role
                while ($user = mysqli_fetch_array($users_result)) {
                    echo '<li data-user-id="' . $user['User_ID'] . '">' . $user['Username'] . '</li>';
                }
            }
            ?>
        </ul>
    </section>
    <section class="chat">
        <h2>Chat</h2>
        <div class="messages">
            <?php while ($message = mysqli_fetch_array($messages_result)) { ?>
                <div class="message">
                    <strong><?php echo $message['SenderName']; ?>:</strong>
                    <p><?php echo $message['Message_Text']; ?></p>
                    <span><?php echo $message['Timestamp']; ?></span>
                </div>
            <?php } ?>
        </div>
        <form action="chat.php" method="post">
            <input type="hidden" id="receiver_id" name="receiver_id" value="">
            <div class="input-container">
                <input type="text" id="message" name="message" placeholder="Type a message" required>
                <button type="submit">Send</button>
            </div>
        </form>
    </section>
    <footer>
        <a href="../logout.php">Log Out</a>
    </footer>
</div>
<script>
    document.querySelectorAll('.users ul li').forEach(user => {
        user.addEventListener('click', function() {
            document.getElementById('receiver_id').value = this.getAttribute('data-user-id');
        });
    });
</script>
</body>
</html>
