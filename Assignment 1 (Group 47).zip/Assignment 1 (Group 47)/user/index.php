<?php
session_start();
include('../db_connection.php');

$conn = OpenCon();

if (isset($_SESSION["mySession"])) {
    $user_id = $_SESSION["mySession"];

    $stmt = $conn->prepare("SELECT * FROM account WHERE User_ID=?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()){
        $username = htmlspecialchars($row['Username'], ENT_QUOTES, 'UTF-8');
    } else {
        // Handle case where user is not found
        echo '<p>User not found.</p>';
        exit();
    }

    $stmt->close();
} else {
    header('Location: ../login.php');
    exit();
}

function displayProfilePicture($profile_picture) {
    if ($profile_picture) {
        echo '<img src="data:image/jpeg;base64,' . base64_encode($profile_picture) . '" alt="Profile Picture">';
    } else {
        echo '<img src="../images/default-profile.jpg" alt="Default Profile Picture">';
    }
}

CloseCon($conn);
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="../css/user.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="../images/logo.jpeg" alt="L&F">
            <h1>Lost & Found</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Homepage</a></li>
                <li><a href="userprofile.php">User profile</a></li>
                <li><a href="chat.php">Chat Room</a></li>
                <li><a href="found.php">Found</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="about.php">About us</a></li>
                <li><a href="../logout.php">Log out</a></li>
            </ul>
        </nav>
    </div>
    <div class="main-content">
        <div class="welcome-section">
            <header>    
                <h1>Welcome <?php echo $username; ?>!</h1>
            </header>
            <h1>MMU Lost & Found.</h1>
            <p>"Reuniting Our Community, One Lost Item at a Time"</p>
        </div>
        <div class="buttons">
            <a href="subitem.php" class="btn">Submit lost item</a>
            <a href="itemlisted.php" class="btn">Items you listed</a>
            <a href="pendingitem.php" class="btn">Pending listed items</a>
        </div>
    </div>
</body>
</html>
