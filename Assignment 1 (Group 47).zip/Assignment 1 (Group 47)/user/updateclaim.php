<?php
session_start();
include('../db_connection.php');

if (!isset($_SESSION['mySession'])) {
    echo '<p>You are not logged in.</p>';
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $claim_id = $_POST['claim_id'];
    $action = $_POST['action'];

    $conn = OpenCon();

    $new_status = ($action == 'approve') ? 'Approved' : 'Rejected';
    
    $query = "UPDATE item_claims SET Claim_Status = '$new_status' WHERE Claim_ID = '$claim_id'";

    if (mysqli_query($conn, $query)) {
        echo '<p>Claim updated successfully.</p>';
    } else {
        echo '<p>Error: ' . mysqli_error($conn) . '</p>';
    }

    CloseCon($conn);
    header('Location: pendingitem.php');
    exit;
}
?>
