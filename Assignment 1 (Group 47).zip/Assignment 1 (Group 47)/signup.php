<?php
// Include the database connection file
include 'db_connection.php';

$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Open connection
    $conn = OpenCon();
    
    // Step 1: Sanitize inputs (already done with mysqli_real_escape_string)
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone_number = mysqli_real_escape_string($conn, $_POST['phone_number']);
    $role = 'User'; // Default role
    $recovery_question = mysqli_real_escape_string($conn, $_POST['recovery_question']);
    $recovery_answer = mysqli_real_escape_string($conn, $_POST['recovery_answer']);
    
    // Step 2: Validate inputs
    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    // Validate phone number (only digits)
    if (!preg_match("/^[0-9]*$/", $phone_number)) {
        $errors[] = "Phone number must contain only digits.";
    }

    // Validate username (3-20 characters, letters and numbers only)
    if (!preg_match("/^[a-zA-Z0-9]{3,20}$/", $username)) {
        $errors[] = "Username must be between 3 and 20 characters long and contain only letters and numbers.";
    }

    // Check if username already exists
    $check_username_query = "SELECT * FROM account WHERE Username = '$username'";
    $check_username_result = $conn->query($check_username_query);
    
    if ($check_username_result && $check_username_result->num_rows > 0) {
        $errors[] = "Username '$username' is already taken. Please choose a different username.";
    }
    
    // Check if email already exists
    $check_email_query = "SELECT * FROM account WHERE Email = '$email'";
    $check_email_result = $conn->query($check_email_query);
    
    if ($check_email_result && $check_email_result->num_rows > 0) {
        $errors[] = "Email '$email' is already registered. Please use a different email address.";
    }
    
    // Process profile picture upload
    $profile_picture = null;
    if ($_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        // Get file contents
        $file_tmp_name = $_FILES['profile_picture']['tmp_name'];
        $profile_picture = file_get_contents($file_tmp_name);
    }
    
    // If no errors, proceed with insertion
    if (empty($errors)) {
        // Do not hash the password, store it as is
        $plain_password = $password;
        
        // Prepare and bind parameters
        $stmt = $conn->prepare("INSERT INTO account (Username, Password, name, Email, Phone_Number, Role, ProfilePicture, recovery_question, recovery_answer) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssssss", $username, $plain_password, $name, $email, $phone_number, $role, $profile_picture, $recovery_question, $recovery_answer);
        
        // Execute the statement
        if ($stmt->execute()) {
            // Retrieve the last inserted User_ID
            $last_user_id = $conn->insert_id;
            echo "New record created successfully with User_ID: " . $last_user_id;
        } else {
            echo "Error: " . $stmt->error;
        }
        
        // Close the statement
        $stmt->close();
    } else {
        // Display errors
        foreach ($errors as $error) {
            echo "<p>Error: $error</p>";
        }
    }
    
    // Close connection
    CloseCon($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Page</title>
    <link href="css/signup.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <section class="copy">
            <img src="images/mmu.png">
            <img src="images/inst-profile-header-mmu.jpg" class="background-img">
            <h1>Welcome to MMU Lost And Found</h1>
            <p>A platform to reunite with your lost belonging.</p>
        </section>
        <form action="signup.php" method="post" enctype="multipart/form-data">
            <section class="copy">
                <h2>Sign Up for a New Account</h2>
                <div class="signup-container">
                    <p>Already a register? <a href="login.php"><strong>Log In</strong></a></p>
                </div>
            </section>
            <div class="input-container name">
                <label for="username">Username</label>
                <input type="text" name="username" required="required">
            </div>
            <div class="input-container email">
                <label for="email">Email</label>
                <input type="email" name="email" required="required">
            </div>
            <div class="input-container name">
                <label for="name">Name</label>
                <input type="text" name="name" required="required">
            </div>
            <div class="input-container phone_number">
                <label for="phone_number">Phone Number</label>
                <input type="tel" name="phone_number" pattern="[0-9]+" required="required" title="Phone number should only contain numbers">
            </div>
            <div class="input-container password">
                <label for="password">Password</label>
                <input type="password" name="password" required="required">
            </div>
            <div class="input-container recovery_question">
                <label for="recovery_question">Recovery Question</label>
                <input type="text" name="recovery_question" required="required">
            </div>
            <div class="input-container recovery_answer">
                <label for="recovery_answer">Recovery Answer</label>
                <input type="text" name="recovery_answer" required="required">
            </div>
            <div class="input-container profile_picture">
                <label for="profile_picture">Profile Picture</label>
                <input type="file" name="profile_picture" accept=".jpg, .png" required="required">
            </div>
            <button class="signup-btn" type="submit" name="signup">Sign Up</button>
        </form>
    </div>
</body>
</html>
