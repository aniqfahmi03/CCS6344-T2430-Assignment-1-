<?php
// Include necessary files
require_once 'db_connection.php';

// Function to sanitize input
function sanitize_input($conn, $input) {
    return mysqli_real_escape_string($conn, $input);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $conn = OpenCon();

    // Sanitize input
    $username = sanitize_input($conn, $_POST['username']);

    // Check if the form is for answering the recovery question or resetting the password
    if (isset($_POST['new_password'])) {
        // If new_password is set, it means the form is for resetting the password
        $new_password = sanitize_input($conn, $_POST['new_password']);

        // Update the user's password in the database
        $update_sql = "UPDATE account SET password = '$new_password' WHERE Username = '$username'";

        if (mysqli_query($conn, $update_sql)) {
            $message = 'Password updated successfully.';
            $message_type = 'message';
        } else {
            $message = 'Error updating password: ' . mysqli_error($conn);
            $message_type = 'error';
        }
    } else {
        // Otherwise, it's for answering the recovery question
        $recovery_answer = sanitize_input($conn, $_POST['recovery_answer']);

        // Verify the recovery answer
        $sql = "SELECT * FROM account WHERE Username = '$username' AND recovery_answer = '$recovery_answer'";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) == 1) {
            // Display form to input new password
            $show_password_form = true;
        } else {
            $message = 'Incorrect answer to recovery question.';
            $message_type = 'error';
        }
    }

    CloseCon($conn);
} else {
    // If form not submitted correctly, redirect to forgot_password.php
    header("Location: forgot_password.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link rel="stylesheet" href="css/reset_password.css">
</head>
<body>
    <div class="container">
        <?php
        if (isset($message)) {
            echo '<div class="' . $message_type . '">' . $message . '</div>';
        }
        if (isset($show_password_form) && $show_password_form) {
            echo '<form action="reset_password.php" method="post">';
            echo '<input type="hidden" name="username" value="' . $username . '">';
            echo '<img src="images/reset.jpg" alt="Reset Password" style="width:300px;height:auto;">';
            echo '<label for="new_password">Enter your new password:</label>';
            echo '<div class="password-wrapper">';
            echo '<input type="password" id="new_password" name="new_password" required>';
            echo '<img src="https://media.geeksforgeeks.org/wp-content/uploads/20210917145551/eye.png" width="24" height="24" id="togglePassword">';
            echo '</div>';
            echo '<button type="submit" name="submit">Reset Password</button>';
            echo '</form>';
        } elseif (!isset($message)) {
            echo '<form action="reset_password.php" method="post">';
            echo '<label for="username">Enter your username:</label>';
            echo '<input type="text" id="username" name="username" required>';
            echo '<label for="recovery_answer">Answer to your recovery question:</label>';
            echo '<input type="text" id="recovery_answer" name="recovery_answer" required>';
            echo '<button type="submit" name="submit">Submit Answer</button>';
            echo '</form>';
        }
        if (isset($message) && $message_type == 'message') {
            echo '<form action="login.php" method="get">';
            echo '<button type="submit">Back to Login</button>';
            echo '</form>';
        }
        ?>
    </div>
    <script>
        const togglePassword = document.querySelector('#togglePassword');
        const password = document.querySelector('#new_password');

        togglePassword.addEventListener('click', function () {
            // Toggle the type attribute
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);

            // Toggle the eye slash icon
            if (togglePassword.src.match("https://media.geeksforgeeks.org/wp-content/uploads/20210917150049/eyeslash.png")) {
                togglePassword.src = "https://media.geeksforgeeks.org/wp-content/uploads/20210917145551/eye.png";
            } else {
                togglePassword.src = "https://media.geeksforgeeks.org/wp-content/uploads/20210917150049/eyeslash.png";
            }
        });
    </script>
</body>
</html>
